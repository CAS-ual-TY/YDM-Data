# YDM-Data
All data used by the YGO Dueling Modification for Minecraft.
